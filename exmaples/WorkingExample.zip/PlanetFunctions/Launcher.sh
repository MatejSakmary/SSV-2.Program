#!/bin/bash	

  java -jar resources/06-Planets-Control.jar


