
import cz.tul.nti.srm.ode.functions.IFunctionTY;

/**
 *
 * @author dalibor
 */
public class Rychlost implements IFunctionTY {

    int iPlanet;
    int iCoor;

    public Rychlost(final int iPlanet, final int iCoor) {
        this.iPlanet = iPlanet;
        this.iCoor = iCoor;
    }

    @Override
    public double value(final double t, final double[] y) {
        double hodnota = 0.0;

        return hodnota;
    }

    @Override
    public float value(final float t, final float[] y) {
        float hodnota = 0.0f;

        double[] yd = new double[y.length];
        System.arraycopy(y, 0, yd, 0, y.length);
        hodnota = (float) value((double) t, yd);

        return hodnota;
    }
}
