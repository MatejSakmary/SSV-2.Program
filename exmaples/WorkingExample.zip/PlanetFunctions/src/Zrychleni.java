
import cz.tul.nti.srm.ode.functions.IFunctionTY;

/**
 *
 * @author dalibor
 */
public class Zrychleni implements IFunctionTY {

    public static final double KAPPA = 6.67e-11;
    //
    int iPlanet;
    int iCoor;

    public Zrychleni(final int iPlanet, final int iCoor) {
        this.iPlanet = iPlanet;
        this.iCoor = iCoor;
    }

    @Override
    public double value(final double t, final double[] y) {
        final int numPlanets = 0;

        final double xi = y[0]; // x-souradnice i-te planety
        final double yi = y[0]; // y-souradnice i-te planety
        final double mi = y[0]; // hmotnost i-te planety

        double ax = 0.0; // zrychleni i-te planety ve smeru x
        double ay = 0.0; // zrychleni i-te planety ve smeru y

        // cyklus pro vsechny planety
        for (int jPlanet = 0; jPlanet < numPlanets; ++jPlanet) {
            if (iPlanet == jPlanet) {
                // preskoc gravitacni pusobeni sama na sebe
                continue;
            }

            final double xj = y[0]; // x-souradnice j-te planety
            final double yj = y[0]; // y-souradnice j-te planety
            final double mj = y[0]; // hmotnost j-te planety

            final double rx = 0.0;
            final double ry = 0.0;
            final double r2 = 0.0;
            final double r = 0.0;
            final double ex = 0.0;
            final double ey = 0.0;

            final double f = 0.0; // gravitacni sila mezi i-tou a j-tou planetou
            final double a = 0.0; // zrychleni i-te planety (zpusobene j-tou planetou)

            ax += a * ex; // x-ova slozka zrychleni i-te planety
            ay += a * ey; // y-ova slozka zrychleni i-te planety
        }

        // vyber pozadovanou slozku zrychleni
        double hodnota = 0.0;
        if (iCoor == 0) {
            hodnota = ax;
        } else {
            hodnota = ay;
        }

        return hodnota;
    }

    @Override
    public float value(final float t, final float[] y) {
        float hodnota = 0.0f;

        double[] yd = new double[y.length];
        System.arraycopy(y, 0, yd, 0, y.length);
        hodnota = (float) value((double) t, yd);

        return hodnota;
    }
}
